import java.util.ArrayList;
import java.util.Collections;

public class MyRunnableBucketSort implements Runnable {

	ArrayList<Integer> bucket;
	public MyRunnableBucketSort(ArrayList<Integer> arraylist) {
		// TODO Auto-generated constructor stub
		this.bucket=arraylist;
	}

	@Override
	public void run() {
		
		 Collections.sort(bucket);

	}

}
