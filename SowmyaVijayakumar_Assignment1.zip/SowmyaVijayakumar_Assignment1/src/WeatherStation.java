import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class WeatherStation {

	String location;
	ArrayList<Measurement> measurements;
	static ArrayList<WeatherStation> stations = new ArrayList<WeatherStation>();

	public WeatherStation(String name, ArrayList<Measurement> mts ) {
		location = name;
		measurements = mts;
		}

	public double averageTemperature(int startTime, int endTime) {
		return measurements.stream().filter(m -> m.time > startTime && m.time < endTime).mapToDouble(m -> m.temp).average()
				.getAsDouble();
	}

	public static double medianTemperature(int startTime, int endTime, ArrayList<String> cities) {

	
		List<Measurement> requestedStations = stations.stream()
				.filter(w -> cities.contains(w.location)).map(w -> w.measurements).flatMap(l->l.stream()).collect(Collectors.toList());
	
		ArrayList<Double> filteredMeasurements = 
				(ArrayList<Double>) requestedStations.stream()
		.filter(m -> m.getTime()> startTime && m.getTime() < endTime).map(m->m.getTemperature()).collect(Collectors.toList()); 
		
		
		
	
		
		
		
	filteredMeasurements.sort(null);
		 
		 double median;
		 if (filteredMeasurements.size() % 2 == 0) 
			 
			 median = filteredMeasurements.get((filteredMeasurements.size()  / 2) + (filteredMeasurements.size()/2 - 1))/2;
			 
		 else {
			 median = filteredMeasurements.get(filteredMeasurements.size() / 2);
		 }
		   
		 
		return median; 
	}
	
	public static int  countTemperatures(double t){
		
		return stations.stream()
		.map(m->m.measurements).flatMap(l->l.stream()).reduce(0, (count,n) -> n.temp>=t-1 && n.temp<=t+1 ? count += 1: count, (count1,count2) -> count1 + count2);
		
		
		
	}

	public static void main(String args[]) {
		// creating the galway station information
		ArrayList<Measurement> galwayMeter = new ArrayList<Measurement>();
		galwayMeter.add(new Measurement(10, 8));
		galwayMeter.add(new Measurement(11, 7));
		galwayMeter.add(new Measurement(12, 11));
		galwayMeter.add(new Measurement(13, 10));
		galwayMeter.add(new Measurement(14, 9));
		galwayMeter.add(new Measurement(15, 8));
		galwayMeter.add(new Measurement(16, 7));
		galwayMeter.add(new Measurement(17, 6));
		galwayMeter.add(new Measurement(18, 5));
		WeatherStation galwayW = new WeatherStation("Galway", galwayMeter);
		// add the station
		stations.add(galwayW);
		// creating the dublin station information
		ArrayList<Measurement> dublinMeter = new ArrayList<Measurement>();
		dublinMeter.add(new Measurement(10, 10));
		dublinMeter.add(new Measurement(11, 12));
		dublinMeter.add(new Measurement(12, 16));
		dublinMeter.add(new Measurement(13, 15));
		dublinMeter.add(new Measurement(14, 13));
		dublinMeter.add(new Measurement(15, 15));
		dublinMeter.add(new Measurement(16, 10));
		dublinMeter.add(new Measurement(17, 9));
		dublinMeter.add(new Measurement(18, 9));
		WeatherStation dublinW = new WeatherStation("Dublin", dublinMeter);
		// add the station
		stations.add(dublinW);
		// creating the dublin station information
		ArrayList<Measurement> corkMeter = new ArrayList<Measurement>();
		corkMeter.add(new Measurement(10, 10));
		corkMeter.add(new Measurement(11, 12));
		corkMeter.add(new Measurement(12, 16));
		corkMeter.add(new Measurement(13, 15));
		corkMeter.add(new Measurement(14, 13));
		corkMeter.add(new Measurement(15, 11));
		corkMeter.add(new Measurement(16, 15));
		corkMeter.add(new Measurement(17, 9));
		corkMeter.add(new Measurement(18, 9));
		WeatherStation corkW = new WeatherStation("Cork", corkMeter);
		// add the station
		stations.add(corkW);
		System.out.println(galwayW.averageTemperature(10, 18));

		ArrayList<String> cities = new ArrayList<>();
		cities.add("Galway");
		cities.add("Cork");
		System.out.println(medianTemperature(10, 18, cities));
         
		System.out.println(countTemperatures(15));
        
	}
}
